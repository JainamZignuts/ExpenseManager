module.exports = {
  attributes: {
    owners: {
      model: 'users',
    },
    account: {
      model: 'account',
    },
  },
};
